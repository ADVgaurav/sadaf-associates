"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";
import { Container } from "@/components/layout";
import { buttonVariants } from "@/components/ui";
import { cn } from "@/lib/utils";
import { fadeUp, transitions } from "@/components/motion";

const indicators = ["Online Consultation", "Business Focused", "Confidential", "Professional Support"] as const;

export function Hero() {
  const reducedMotion = useReducedMotion();
  return <section className="relative isolate overflow-hidden pb-20 pt-20 sm:pb-24 sm:pt-28 lg:pb-32 lg:pt-40">
    <HeroBackground reducedMotion={reducedMotion} />
    <Container size="wide" className="relative">
      <motion.div initial="hidden" animate="visible" variants={reducedMotion ? undefined : { visible: { transition: { staggerChildren: 0.08 } } }} className="max-w-4xl">
        <motion.p variants={reducedMotion ? undefined : fadeUp} className="mb-6 text-xs font-medium uppercase tracking-[0.18em] text-accent">Legal & Corporate Consultancy</motion.p>
        <motion.h1 variants={reducedMotion ? undefined : fadeUp} className="max-w-3xl font-display text-5xl leading-[1.08] tracking-[-0.035em] text-foreground sm:text-6xl lg:text-7xl">Practical Legal Solutions <span className="text-[hsl(var(--text-secondary))]">for Startups, MSMEs &amp; Businesses.</span></motion.h1>
        <motion.p variants={reducedMotion ? undefined : fadeUp} className="mt-7 max-w-2xl text-lg leading-8 text-[hsl(var(--text-secondary))]">Professional legal support for businesses through secure online consultations across India.</motion.p>
        <motion.div variants={reducedMotion ? undefined : fadeUp} className="mt-10 flex flex-col gap-3 sm:flex-row"><Link href="/contact" className={cn(buttonVariants({ variant: "primary" }), "w-full sm:w-auto")}>Schedule Consultation <ArrowRight className="size-4" aria-hidden="true" /></Link><Link href="/contact" className={cn(buttonVariants({ variant: "secondary" }), "w-full sm:w-auto")}>Contact Us</Link></motion.div>
        <motion.ul variants={reducedMotion ? undefined : fadeUp} className="mt-12 flex flex-wrap gap-x-5 gap-y-3 text-sm text-[hsl(var(--text-muted))]">{indicators.map((indicator) => <li key={indicator} className="flex items-center gap-2"><span className="flex size-5 items-center justify-center rounded-full bg-[hsl(var(--accent-subtle))] text-accent"><Check className="size-3" strokeWidth={2.5} aria-hidden="true" /></span>{indicator}</li>)}</motion.ul>
      </motion.div>
    </Container>
  </section>;
}

function HeroBackground({ reducedMotion }: { reducedMotion: boolean | null }) {
  return <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 overflow-hidden"><div className="absolute inset-0 bg-[radial-gradient(circle_at_78%_15%,hsl(var(--accent-subtle)),transparent_32%),linear-gradient(135deg,hsl(var(--canvas-default)),hsl(var(--canvas-subtle)))]" /><div className="absolute inset-0 opacity-40 [background-image:linear-gradient(hsl(var(--border-subtle))_1px,transparent_1px),linear-gradient(90deg,hsl(var(--border-subtle))_1px,transparent_1px)] [background-size:72px_72px]" /><motion.svg viewBox="0 0 1440 420" className="absolute inset-x-0 top-20 h-[420px] w-full text-accent opacity-30" fill="none" initial={reducedMotion ? false : { opacity: 0 }} animate={{ opacity: 0.3 }} transition={transitions.slow}><motion.path d="M-80 290C210 90 405 410 698 205s476-105 822-254" stroke="currentColor" strokeWidth="1" initial={reducedMotion ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: reducedMotion ? 0 : 1.6, ease: "easeOut" }} /><motion.path d="M-30 340C270 130 498 460 770 264s416-78 748-206" stroke="currentColor" strokeOpacity="0.45" strokeWidth="1" initial={reducedMotion ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: reducedMotion ? 0 : 1.9, ease: "easeOut", delay: 0.12 }} /></motion.svg></div>;
}
