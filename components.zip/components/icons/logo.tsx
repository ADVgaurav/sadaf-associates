import type { SVGProps } from "react";
import { cn } from "@/lib/utils";

export function Logo({ className, ...props }: SVGProps<SVGSVGElement>) {
  return <svg viewBox="0 0 40 40" fill="none" aria-hidden="true" className={cn("size-8", className)} {...props}><path d="M8 30 20 7l12 23" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M13 21h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>;
}
