import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function absoluteUrl(path = "/") {
  return new URL(path, process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.sadafassociates.in").toString();
}
